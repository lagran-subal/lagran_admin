from django.apps import AppConfig


class LagranAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lagran_admin'
