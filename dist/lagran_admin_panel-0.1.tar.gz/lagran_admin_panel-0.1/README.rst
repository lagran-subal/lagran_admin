Quick Start
==============

INSTALLED_APPS = [
    ...
    'lagran_admin'
]

python manage.py migrate