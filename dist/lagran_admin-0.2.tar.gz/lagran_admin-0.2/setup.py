from setuptools import setup

setup(
    name = 'lagran_admin',
    version = '0.2'
    )