Quick Start
==============

INSTALLED_APPS = [
    
    'lagran_admin',
    'django.contrib.admin',
]


python manage.py migrate